package funcs

func Searsh(start, end string, m map[string][]string, path []string, ar [][]string) [][]string {
	if start == end {
		path = path[1:]
		ar = append(ar, path)
		return ar
	}
	for i := 0; i < len(m[start]); i++ {
		if check(path, m[start][i]) {
			newrr := make([]string, len(path))
			for i := 0; i < len(newrr); i++ {
				newrr[i] = path[i]
			}
			newrr = append(newrr, m[start][i])
			ar = Searsh(start, end, m, newrr, ar)
		}
	}
	return ar
}

func check(ar []string, n string) bool {
	for i := 0; i < len(ar); i++ {
		if ar[i] == n {
			return false
		}
	}
	return true
}
func Sort(ar [][]string) {
	for i := 0; i < len(ar); i++ {
		for j := i + 1; j < len(ar); j++ {
			if len(ar[i]) > len(ar[j]) {
				ar[i], ar[j] = ar[j], ar[i]
			}
		}
	}
}
func Delete(ar [][]string) [][]string {
	m := make(map[string]int)
	s := [][]string{ar[0]}
	for i := 0; i < len(ar[0])-1; i++ {
		m[ar[0][i]]++
	}
	for i := 1; i < len(ar); i++ {
		bl := true
		for j := 0; j < len(ar[i])-1; j++ {
			if m[ar[i][j]] != 0 {
				bl = false
				break
			}
		}
		if bl {
			s = append(s, ar[i])
			for j := 1; j < len(ar[i])-1; j++ {
				m[ar[i][j]]++
			}
		} else {
			ar[i] = []string{}
		}
	}
	return s
}
