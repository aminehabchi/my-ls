package funcs

import (
	"strconv"
)

type Ants struct {
	Room string
	Ant  string
	I    int
	J    int
}

// var x int = 1

func Print(ar [][]string, Nants int) string {
	paths := []Ants{}
	n := 1
	output := ""

	for {
		paths = deleteEnd(paths)
		if Nants+1 == n && len(paths) == 0 {
			break
		}
		for i := 0; i < len(paths); i++ {
			paths[i].Room = ar[paths[i].I][paths[i].J+1]
			paths[i].J += 1
		}
		if Nants+1 != n {
			for i := 0; i < len(ar); i++ {
				newAnt := Ants{Room: ar[i][0], Ant: "L" + strconv.Itoa(n), I: i, J: 0}
				n++
				paths = append(paths, newAnt)
				if Nants+1 == n {
					break
				}
			}
		}
		//print line
		output += PrintlnPath(paths)
	}
	return output
}
func PrintlnPath(paths []Ants) string {
	out := ""
	for i := 0; i < len(paths); i++ {
		out = out + paths[i].Ant + "-" + paths[i].Room
		if i != len(paths) {
			out = out + " "
		}
	}
	out = out + "\n"
	return out
}
func deleteEnd(a []Ants) []Ants {
	b := []Ants{}
	for i := 0; i < len(a); i++ {
		if a[i].Room != End {
			b = append(b, a[i])
		}
	}
	return b
}
