package main

import (
	"bytes"
	"fmt"
	"os"
	"os/exec"
	"strings"
)

func main() {
	arr := []string{"ex1.txt", "ex2.txt", "ex3.txt", "ex4.txt", "ex5.txt", "ex6.txt"}
	for i := 0; i < len(arr); i++ {
		out, _ := runFile("/home/amine/Desktop/lem-in/main/main.go", "/home/amine/Desktop/lem-in/exm/"+arr[i])
		solut, _ := os.ReadFile("/home/amine/Desktop/lem-in/solutions/" + arr[i])

		if len(strings.Split(out, "\n")) != len(strings.Split(string(solut), "\n")) {
			fmt.Printf("error in file : %d\n", i+1)
		} else {
			fmt.Printf("file %d passe correct\n", i+1)
		}
	}
}

func runFile(fileName string, args string) (string, error) {
	cmd := exec.Command("go", "run", fileName, args)
	var out bytes.Buffer
	cmd.Stdout = &out
	cmd.Stderr = &out
	err := cmd.Run()
	if err != nil {
		return "", err
	}
	return out.String(), nil
}
