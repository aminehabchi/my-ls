package main

import (
	"fmt"
	funcs "funcs/func"
	"os"
)

func main() {
	//t := time.Now()
	if len(os.Args) != 2 {
		return
	}
	fileName := os.Args[1]
	arr, err := funcs.ReadFile(fileName)
	if err != nil {
		fmt.Println(err)
		return
	}

	m := make(map[string][]string)
	for i := 0; i < len(arr); i++ {
		m[arr[i][0]] = append(m[arr[i][0]], arr[i][1])
		m[arr[i][1]] = append(m[arr[i][1]], arr[i][0])
	}

	ar := funcs.Searsh(funcs.Start, funcs.End, m, []string{funcs.Start}, [][]string{})

	funcs.Sort(ar)

	ar = funcs.Delete(ar)

	o := funcs.Print(ar, funcs.N)

	fmt.Print(o)

	//time
	//fmt.Println("")
	//fmt.Println(time.Since(t))
}
